<?php
	$host = "localhost";
	$user = "root";
	$senha = "";
	$banco = "id15497095_banco";

	$conexao = mysqli_connect($host, $user, $senha, $banco);
?>